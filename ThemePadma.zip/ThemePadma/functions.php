<?php

/**
 * Proper way to enqueue scripts and styles.
 */
function wpdocs_theme_name_scripts() {
	wp_enqueue_style( 'style-name', get_stylesheet_uri() );
	wp_enqueue_style( 'style-name1', get_template_directory_uri().'/assets/css/bootstrap.min.css' );
	wp_enqueue_script( 'script-name', get_template_directory_uri() . '/assets/js/bootstrap.bundle.min.js', array(), '1.0.0', true );
}
add_action( 'wp_enqueue_scripts', 'wpdocs_theme_name_scripts' );


add_theme_support( 'title-tag' );
add_theme_support( 'custom-logo' );
add_theme_support( 'post-thumbnails' );



if ( ! function_exists( 'mytheme_register_nav_menu' ) ) {

	function mytheme_register_nav_menu(){
		register_nav_menus( array(
	    	'primary_menu' => __( 'Primary Menu', 'text_domain' ),
	    	'footer_menu'  => __( 'Footer Menu', 'text_domain' ),
		) );
	}
	add_action( 'after_setup_theme', 'mytheme_register_nav_menu', 0 );
}

register_sidebar([
    'name'=>'BD Logo',
    'id'=>'bdlogo',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Hero Title',
    'id'=>'herotitle',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Hero card1',
    'id'=>'herocard1',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Hero card2',
    'id'=>'herocard2',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Hero card3',
    'id'=>'herocard3',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Line Left',
    'id'=>'lineleft',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Photo Line',
    'id'=>'photoline',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Line Right',
    'id'=>'lineright',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Photo Card 1',
    'id'=>'photocard1',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Photo Card 2',
    'id'=>'photocard2',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Photo Card 3',
    'id'=>'photocard3',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'Photo Card 4',
    'id'=>'photocard4',
    'before_widget'=>'',
    'after_widget'=>''
]);
register_sidebar([
    'name'=>'News Line',
    'id'=>'newsline',
    'before_widget'=>'',
    'after_widget'=>''
]);


?>