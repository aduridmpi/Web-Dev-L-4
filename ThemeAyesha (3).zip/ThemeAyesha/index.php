<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bangladesh</title>
    <link rel="stylesheet" href="style.css">
     <link rel="stylesheet" href="."> 
   
     <?php wp_head(); ?>
</head>
<body>
    <!--Header part start  -->

<header class="cont">
   <div class="row topbar">
    <div class="col-lg-6 header_left">
        <p>বাংলাদেশ জাতীয় তথ্য বাতায়ন</p>
    </div>
    <div class="col-lg-6 header_right text-end">
        <p>২৩ কার্তিক, ১৪২৯</p>
        <a href="#">English</a>
    </div>
   </div>
</header>

    <!--Header part end  -->

    <!-- logo part start -->
    <section class="cont">
        <div class="row logo">
        <div class=" col-lg-5 logo_left">
            <a href="#"> 
              <?php the_custom_logo(); ?>
                <img src="./assets/Images/Header/logo_bn.png" alt="">
            </a>
        </div>
        <div class=" col-lg-5 logo_search">
            <form action="">
                <input type="text" placeholder="খুঁজুন "  >
                <button>অনুসন্ধান </button>
            </form>
        </div>
        <div class=" col-lg-2 logo_right d-flex justify-content-end">
            <div class="logo1">
                <a href="#"><img src="./assets/Images/Header/a2i-logo-footer.png" alt=""></a>
            </div>
            <div class="logo2">
               <h5><b>সাথে থাকুন:</b></h5>
               <a href=""><img src="./assets/Images/Header/facebook-icon.png" alt=""> </a>
               <a href=""><img src="./assets/Images/Header/twitter-blue-icon.png" alt=""> </a>
               <a href=""><img src="./assets/Images/Header/youtube-icon.png" alt=""> </a>
               <a href=""><img src="./assets/Images/Header/gplus-icon.png" alt=""> </a>
            </div>
        </div>
    </div>
    </section>
    <!-- logo part end -->
    <!-- menu part start -->
    <section class="cont">
        <div class="row main-menu">
            <nav class="navbar navbar-expand-lg bg-light">
                <div class="container-fluid">
                  
                  <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <?php wp_nav_menu(array(
                      'menu_location'=>'Top_menu',
                      'menu_class'=>'navbar-nav top_menu'
                    )); ?>
                  <!-- <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">হোম</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">বাংলাদেশ সম্পর্কিত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ই-সেবাসমূহ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">সেবাখাত</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ব্যবসা-বাণিজ্য</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ব্যবসা-বাণিজ্য</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">আইন-বিধি</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">তথ্য বাতায়ন</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">সেবাকুঞ্জ</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#">ফরমস</a>
                      </li>
                      
                    </ul> -->
                    
                  </div>
                </div>
              </nav>
        </div>
    </section>
    <!-- menu part end -->
    <!-- Hero part start -->
    <section class="cont">
      <div class="row hero">
        <div class="hero-main col-lg-8">
          <div class="banner">
            <a href="#"> 
              <?php dynamic_sidebar('banner'); ?>
              <img src="./assets/Images/padmabanner.jpg" class="d-block w-100" alt="">
            </a>
          </div>
<!-- slider start -->
          <div class="slider">
            <div id="carouselExampleFade" class="carousel slide carousel-fade" data-bs-ride="carousel">
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="./assets/Images/Slider/our_pride.png" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/Slider/myGov Static2(1) (1).jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/Slider/pmobanner.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/Slider/0.jpg" class="d-block w-100" alt="...">
                </div>
                <div class="carousel-item">
                  <img src="./assets/Images/Slider/Banner-2.jpg" class="d-block w-100" alt="...">
                </div>
              </div>
              <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
              </button>
              <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleFade" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
              </button>
            </div>
          </div>
          <!-- slider end -->

          <!-- tab start -->
          <div class="tab">
            <ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
              <li class="nav-item" role="presentation">
                <button class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">জনপ্রিয় সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">নতুন সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">মোবাইল সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false" >দপ্তর ভিত্তিক সেবা</button>
              </li>
              <li class="nav-item" role="presentation">
                <button class="nav-link" id="pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#pills-disabled" type="button" role="tab" aria-controls="pills-disabled" aria-selected="false" >সকল ই-সেবা</button>
              </li>
            </ul>
            <div class="tab-content" id="pills-tabContent">
              <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0"></div>
              <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab" tabindex="0">B</div>
              <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab" tabindex="0">
                <div class="row">
                  <div class="col-lg-2">
                    <img src="./assets/Images/Tab/helpdesk.png" alt="">
                    <p> হেল্পডেস্ক </p>
                  </div>
                  <div class="col-lg-2">
                    <img src="./assets/Images/Tab/agriculture.png" alt="">
                    <p> 
                      কৃষি </p>
                  </div>
                  <div class="col-lg-2">
                    <img src="./assets/Images/Tab/call_center.png" alt="">
                    <p>
                      কল সেন্টার                                 </p>
                  </div>
                  <div class="col-lg-2">
                    <img src="./assets/Images/Tab/mobile_service.png" alt="">
                    <p> 
                      মোবাইল সেবা                               </p>
                  </div>
                  <div class="col-lg-2">
                    <img src="./assets/Images/Tab/agriculture.png" alt="">
                    <p> 
                      মৎস্য ও প্রাণী  </p>
                  </div>
                </div>
              </div>
              <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">D</div>
              <div class="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">E</div>
            </div>
          </div>
          <!-- tab end -->
           <!-- List part start -->
          <div class="list">
          <?php dynamic_sidebar('list'); ?>

             <!-- <h5> <b>উদ্যোগ</b></h5>
             
            <ul>
              <li><a href="">
               
                
              </a></li>
               <li><a href="">বাংলাদেশে ঘূর্ণিঝড়ের জরুরি প্রস্তুতি পরিকল্পনা। (১১-০৪-২০১৫) </a></li>
              <li><a href=""> বাংলাদেশ সরকারের ষষ্ঠ পঞ্চবার্ষিক পরিকল্পনা। (০৭-০৪-২০১৫)</a></li>
              <li><a href="">বাংলাদেশ সরকারের প্রেক্ষিত পরিকল্পনা (২০১০-২০২১)। (০৭-০৪-২০১৫)</a></li>
              <li><a href="">দূর্যোগ ব্যবস্থাপনা জন্য জাতীয় পরিকল্পনা ২০১০-২০১৫। (০৭-০৪-২০১৫)</a></li> 
            </ul>  -->
          </div>
         <!-- List part end -->
          <div class="Others">othr</div>
        </div>
        <div class="hero-side col-lg-4">
          <div class="side-img">
              <a href="#">

              <?php dynamic_sidebar('sideimg'); ?>
                <!-- <img src="./assets/Images/Sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100 mb-2" alt=""> -->
              </a>
              <!-- <a href="https://surokkha.gov.bd/"><img src="./assets/Images/Sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100 mb-2" alt=""></a>
              <a href="https://surokkha.gov.bd/"><img src="./assets/Images/Sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100 mb-2" alt=""></a>
              <a href="https://surokkha.gov.bd/"><img src="./assets/Images/Sidebar/bangladesh-portal--batton-bangla.png" class="d-block w-100 mb-2" alt=""></a>
              -->

          </div>
          <h4>সকল বাতায়ন</h4>
          <form action="">
            <select name="" id="">
              <option value="">ওয়েবসাইট বাছাই করুন</option>
              <option value="">মন্ত্রণালয়</option>
              <option value="">অধিদপ্তর </option>
              <option value="">ঢাকা বিভাগ</option>
              <option value="">চট্টগ্রাম বিভাগ</option>
              <option value="">রাজশাহী বিভাগ</option>
              <option value="">খুলনা বিভাগ</option>
              <option value="">বরিশাল বিভাগ</option>
              <option value="">রংপুর বিভাগ</option>
              <option value="">সিলেট বিভাগ</option>
              
            </select>
            <button>চলুন</button>
          </form>
          <div class="side-video">
            <h5>মুজিব১০০ আ্যাপ</h5>
            <?php dynamic_sidebar('sidevideo'); ?>
            <!-- <iframe width="315" height="200" src="https://www.youtube.com/embed/4Om3kZJL-qU" title="MUJIB100 APP | Speeches, Quotes, Books & More | Get Inspired Everyday" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
            <!-- <h5>মাস্ক পরুন সেবা নিন</h5>

            <img src="./assets/Images/Sidebar/mask-bd-portal (1).jpg"alt="">
            <h4>ডেঙ্গু প্রতিরোধে করণীয়</h4>
            <img src="./assets/Images/Sidebar/dengu.jpg"  alt=""> -->
          </div>
        </div>
      </div>
    </section>
    <!-- Hero part end -->
    <!-- Footer part start -->
    <footer class="cont">
      <div class="row footer_main">
        <?php dynamic_sidebar('footertop'); ?>
        <!-- <img src="./assets/Images/Footer/footer_top_bg.png" alt=""> -->
      </div>
     
      <div class="row footer_bottom">
        <div class="col-lg-7 fb_left">
          <?php dynamic_sidebar('footerleft'); ?>
        </div>
        <div class="col-lg-5 fb_right text-end">
          <?php dynamic_sidebar('footerright'); ?>

        </div>
      </div>

    </footer>
    <!-- Footer part end -->

<?php wp_footer(); ?>
    <script src="./assets/JS/bootstrap.bundle.min.js"></script>

    <section class="cont">
    <?php 
    $x=0;
    while($x<=100){
      ($x%3==0)? print $x.'<br>' : '';
      $x=$x+5;
    }
    
    ?>
    </section>
</body>
</html>