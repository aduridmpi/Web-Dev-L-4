
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="adori">

<?php
echo ' <h1>Hello World!</h1>';
echo "Welcome";
echo "<h1>Aduri</h1>";
echo "<h2>Dhaka Mohila Polytechnic Institute</h2>";
echo "<h3>Computer</h3>";

?>
</div>   
</body>
</html>